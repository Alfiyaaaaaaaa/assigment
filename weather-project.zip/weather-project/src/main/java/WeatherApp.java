import java.util.Scanner;
import org.json.JSONObject;


public class WeatherApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите название города:");
        String city = scanner.nextLine();
        
        String response = WeatherService.getWeather(city);
        printFormattedWeather(response);
    }
    public static void printFormattedWeather(String jsonResponse) {
        JSONObject jsonObject = new JSONObject(jsonResponse);

        String cityName = jsonObject.getString("name");
        JSONObject main = jsonObject.getJSONObject("main");
        double temperature = main.getDouble("temp");
        double feelsLike = main.getDouble("feels_like");
        int humidity = main.getInt("humidity");
        String weatherDescription = jsonObject.getJSONArray("weather").getJSONObject(0).getString("description");

        System.out.println("Погода в городе " + cityName + ":");
        System.out.println("Температура: " + temperature + "°C");
        System.out.println("Ощущается как: " + feelsLike + "°C");
        System.out.println("Влажность: " + humidity + "%");
        System.out.println("Описание: " + weatherDescription);
    }
}
