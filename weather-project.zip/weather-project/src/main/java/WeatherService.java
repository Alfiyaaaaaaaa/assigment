import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class WeatherService {

    private static final String API_KEY = "ba2627e6004d02d6c177fd7d4ccc7abf";
    private static final String API_ENDPOINT = "http://api.openweathermap.org/data/2.5/weather?q=%s&units=metric&appid=%s";

    public static String getWeather(String city) {
        String response = "";
        try {
            URL url = new URL(String.format(API_ENDPOINT, city, API_KEY));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode == 200) { // success
                Scanner scanner = new Scanner(url.openStream());
                while (scanner.hasNext()) {
                    response += scanner.nextLine();
                }
                scanner.close();
            } else {
                return "Error fetching weather data";
            }
        } catch (IOException e) {
            return "Error: " + e.getMessage();
        }
        return response;
    }
}
